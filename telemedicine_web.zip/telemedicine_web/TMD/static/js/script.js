document.getElementById('startConsultation').addEventListener('click', function() {
    window.location.href = 'personal_info.html';
});
